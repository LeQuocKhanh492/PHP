For example plugins check [Creating CKFinder 3 Plugins](https://ckeditor.com/docs/ckfinder/ckfinder3/#!/guide/dev_plugins)
